﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnThiASP
{
    public partial class Default5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack != true)
            {
                string sHoTen = "“Hello”";
                Response.Write(sHoTen);
            }
            if (Request.Form["txtHoTen"] !=null)
            {
                Response.Write("Họ Tên:"+ Request.Form["txtHoTen"]);
            }
            if (Button1.CausesValidation)
            {
                Response.Write("Đã Xác thực");
            }
            else
            {
                Response.Write("Chưa xác thực");
            }

            ctrl.ForeColor = Color.FromArgb(2, 2, 2, 2);
            ctrl.ForeColor = Color.Crimson;
            ctrl.ForeColor = ColorTranslator.FromHtml("Blue");
            ctrl.ForeColor = Color.FromArgb(240, 25, 234);


            foreach (ListItem item in CheckBoxList1.Items)
            {
                Response.Write(item.Text.ToString());
            }
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;DataSource = C:\\DataSources\\Northwind.mdb");
            string connectstring = WebConfigurationManager.ConnectionStrings["db2ConnectionString"].ConnectionString;
            SqlConnection conn1 =new SqlConnection();
            //string a =Session["abc"].ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string extention = Path.GetExtension(FileUpload1.FileName);
            if (extention == ".png")
            {
                FileUpload1.SaveAs(Server.MapPath("img//") + Guid.NewGuid() + FileUpload1.FileName);
            }
            
        }
    }
}