﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnThiASP
{
    public partial class Default2 : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Label1.Text = "";
            if (FileUpload1.HasFile)
            {
                string extention = Path.GetExtension(FileUpload1.FileName);
                if (extention ==".jpg" || extention == ".png")
                {
                    FileUpload1.SaveAs(Server.MapPath("img//") + Guid.NewGuid().ToString() + FileUpload1.FileName);
                }
                else
                {
                    Label1.Text = "Ảnh không đúng định dạng";
                }
               
            }
            else
            {
                Label1.Text = "Ảnh không tồn tại";
            }
            
        }
    }
}