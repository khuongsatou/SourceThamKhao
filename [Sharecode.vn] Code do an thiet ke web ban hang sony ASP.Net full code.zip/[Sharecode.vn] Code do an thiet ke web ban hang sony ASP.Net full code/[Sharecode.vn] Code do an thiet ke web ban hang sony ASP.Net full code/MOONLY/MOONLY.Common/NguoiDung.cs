using System;
using System.Collections.Generic;
using System.Text;

namespace MOONLY.Common
{
   public class NguoiDung
    {
        private int _idnguoidung;
        public int Idnguoidung
        {
            get { return _idnguoidung; }
            set { _idnguoidung = value; }
        }
        private int _idkieunguoidung;
        public int Idkieunguoidung
        {
            get { return _idkieunguoidung; }
            set { _idkieunguoidung = value; }
        }
        private string _hoten;
        public string Hoten
        {
            get { return _hoten; }
            set { _hoten = value; }
        }
        private string _tendangnhap;
        public string Tendangnhap
        {
            get { return _tendangnhap; }
            set { _tendangnhap = value; }
        }
        private string _diachi;
        public string Diachi
        {
            get { return _diachi; }
            set { _diachi = value; }
        }
        private string _matkhau;
        public string Matkhau
        {
            get { return _matkhau; }
            set { _matkhau = value; }
        }
        private string _sodienthoai;
        public string Sodienthoai
        {
            get { return _sodienthoai; }
            set { _sodienthoai = value; }
        }
        private string _sofax;
        public string Sofax
        {
            get { return _sofax; }
            set { _sofax = value; }
        }
        private string _Email;
        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        private string _madienthoai;
        public string Madienthoai
        {
            get { return _madienthoai; }
            set { _madienthoai = value; }
        }
    }
}
