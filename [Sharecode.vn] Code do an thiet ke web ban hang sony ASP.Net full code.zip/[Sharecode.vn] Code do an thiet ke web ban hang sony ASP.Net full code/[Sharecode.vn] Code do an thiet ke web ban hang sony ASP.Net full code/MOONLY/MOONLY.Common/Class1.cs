using System;
using System.Collections.Generic;
using System.Text;

namespace MOONLY.Common
{
    public class Class1
    {
    }
}
