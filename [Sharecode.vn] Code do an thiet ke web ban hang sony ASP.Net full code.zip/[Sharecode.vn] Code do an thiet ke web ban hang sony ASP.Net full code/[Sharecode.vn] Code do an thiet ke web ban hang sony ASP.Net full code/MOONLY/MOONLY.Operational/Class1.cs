using System;
using System.Collections.Generic;
using System.Text;

namespace MOONLY.Operational
{
    public class Class1
    {
    }
}
