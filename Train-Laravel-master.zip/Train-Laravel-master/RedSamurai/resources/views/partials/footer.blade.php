<div id="footer-wrap">
    <footer>
        <a href="#header-top">
            <img src="images/to-top.png" alt="home-pin" class="wow fadeIn">
        </a>
        <article>
            <p>The <span>Red</span> Samurai <span class="copy">- All rights reserved 2014</span></p>
            <ul class="social">
                <li><a href="#" class="social-icon fb"></a></li>
                <li><a href="#" class="social-icon twt"></a></li>
                <li><a href="#" class="social-icon gplus"></a></li>
                <li><a href="#" class="social-icon rss"></a></li>
                <li><a href="#" class="social-icon vimeo"></a></li>
                <li><a href="#" class="social-icon flickr"></a></li>
            </ul>
        </article>
    </footer>
</div>