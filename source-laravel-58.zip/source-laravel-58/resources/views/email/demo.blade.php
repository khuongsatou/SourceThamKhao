Xin Chao <i>{{$demo->nguoi_nhan}}</i>
<p>Day la email duoc gui tu he thong cdth17pm</p>

<p><u>Cac gia tri cua object:</u></p>

<div>
    <p><b>Noi Sinh:</b> {{$demo->noi_sinh}} </p>
    <p><b>Noi Sinh:</b> {{$demo->nam_sinh}} </p>
    
    
</div>
<p> <u> Cac gia tr duoc truyen</u></p>
<div>
    <p><b>Gia tri 1:</b> {{$gia_tri_1}} </p>
    <p><b>Gia tri 2:</b> {{$gia_tri_1}} </p>
</div>
Tran Trong.Whoops
<br>
<i>{{$demo->nguoi_gui}}</i>
