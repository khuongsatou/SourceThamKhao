Xin Chao {{$demo->nguoi_nhan}}
Day la email duoc gui tu he thong cdth17pm

Cac gia tri cua object:


    Noi Sinh:{{$demo->noi_sinh}}
    Noi Sinh: {{$demo->nam_sinh}}
    
    

 Cac gia tr duoc truyen

    Gia tri 1: {{$gia_tri_1}}
   Gia tri 2: {{$gia_tri_1}} 

Tran Trong.Whoops

{{$demo->nguoi_gui}}
