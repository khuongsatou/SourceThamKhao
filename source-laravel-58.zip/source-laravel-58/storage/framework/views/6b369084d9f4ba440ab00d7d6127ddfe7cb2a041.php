Xin Chao <i><?php echo e($demo->nguoi_nhan); ?></i>
<p>Day la email duoc gui tu he thong cdth17pm</p>

<p><u>Cac gia tri cua object:</u></p>

<div>
    <p><b>Noi Sinh:</b> <?php echo e($demo->noi_sinh); ?> </p>
    <p><b>Noi Sinh:</b> <?php echo e($demo->nam_sinh); ?> </p>
    
    
</div>
<p> <u> Cac gia tr duoc truyen</u></p>
<div>
    <p><b>Gia tri 1:</b> <?php echo e($gia_tri_1); ?> </p>
    <p><b>Gia tri 2:</b> <?php echo e($gia_tri_1); ?> </p>
</div>
Tran Trong.Whoops
<br>
<i><?php echo e($demo->nguoi_gui); ?></i>
<?php /**PATH D:\source-laravel-58\resources\views/email/demo.blade.php ENDPATH**/ ?>