Xin Chao <?php echo e($demo->nguoi_nhan); ?>

Day la email duoc gui tu he thong cdth17pm

Cac gia tri cua object:


    Noi Sinh:<?php echo e($demo->noi_sinh); ?>

    Noi Sinh: <?php echo e($demo->nam_sinh); ?>

    
    

 Cac gia tr duoc truyen

    Gia tri 1: <?php echo e($gia_tri_1); ?>

   Gia tri 2: <?php echo e($gia_tri_1); ?> 

Tran Trong.Whoops

<?php echo e($demo->nguoi_gui); ?>

<?php /**PATH D:\source-laravel-58\resources\views/email/demo_plain.blade.php ENDPATH**/ ?>